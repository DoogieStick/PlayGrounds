import { Equipment } from './equipment';

export const EQUIPMENTS_ON_LOAD : Equipment [] = [
    
       {id: 1,
        "code": "1 Flags",
        "description": "Amusement Park",
        "selfManufactured": "Sim",
        } ,
		
		{id: 2,
        "code": "2 Flags",
        "description": "Amusement Park",
        "selfManufactured": "Sim",
        } ,
		
		{id: 3,
        "code": "3 Flags",
        "description": "Amusement Park",
        "selfManufactured": "Sim",
        } ,

		{id: 4,
        "code": "4 Flags",
        "description": "Amusement Park",
        "selfManufactured": "Sim",
        } ,	

		{id: 5,
        "code": "5 Flags",
        "description": "Amusement Park",
        "selfManufactured": "Sim",
        } 		

];