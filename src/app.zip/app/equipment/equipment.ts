export interface Equipment {
    id: number;
    code: string;
    description: string;
    selfManufactured: string;    
}