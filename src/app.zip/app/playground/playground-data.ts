import { Playground } from './playground';

export const PLAYGROUNDS_ON_LOAD : Playground [] = [
    
       {id: 1,
        "name": "Six Flags",
        "description": "Amusement Park",
        "address": "Adams Avenue, Rossvelt st 1396",
        "locality": "Chicago City",
        "state": "Illinois",
        "country": "USA"
        },
        
        {id: 2,
        "name": "Universal",
        "description": "Amusement Park",
        "address": "Kentucky st, 96 east",
        "locality": "Orlando City",
        "state": "Florida",
        "country": "USA"
        },
        
        {id: 3,
        "name": "Walt Disney World",
        "description": "Amusement Park",
        "address": "Walt Disney, FL 1396",
        "locality": "Orlando City",
        "state": "Florida",
        "country": "USA"
        },
        
        {id: 4,
        "name": "Cedar Point",
        "description": "Amusement Park",
        "address": "1 Cedar Point Dr, Sandusk",
        "locality": "Columbus City",
        "state": "Ohio",
        "country": "USA"
        }

];